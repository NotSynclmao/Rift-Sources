#pragma once

#define CURL_STATICLIB
#include <iostream>
#include "../JSON/json.hpp"
#include "curl/curl.h"

#ifdef _DEBUG
#pragma comment (lib, "curl/libcurl_a_debug.lib")
#else
#pragma comment (lib, "curl/libcurl_a.lib")
#endif

#pragma comment (lib, "Normaliz.lib")
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Wldap32.lib")
#pragma comment (lib, "Crypt32.lib")
#pragma comment (lib, "advapi32.lib")

size_t writeFunction(void* ptr, size_t size, size_t nmemb, std::string* data) {
    data->append((char*)ptr, size * nmemb);
    return size * nmemb;
}

nlohmann::json GetLoadoutFromAPI(std::string AccountName)
{
    auto URLBaseEncrypted = skCrypt("https://api.riftfn.xyz/fortnite/api/game/v2/internal/profile/");
    std::string URLBaseDecrypted = URLBaseEncrypted.decrypt();
    std::string URL = URLBaseDecrypted.append(AccountName);
    URLBaseEncrypted.clear();

    curl_global_init(CURL_GLOBAL_DEFAULT);
    auto curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, URL.c_str());
        curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 1L);
        curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 50L);
        curl_easy_setopt(curl, CURLOPT_TCP_KEEPALIVE, 1L);

        std::string response_string;
        std::string header_string;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeFunction);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_string);
        curl_easy_setopt(curl, CURLOPT_HEADERDATA, &header_string);

        curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        curl_global_cleanup();

        curl = NULL;

        return nlohmann::json::parse(response_string);
    }
    return nlohmann::json::parse("{}"); //No clue if this is appropriate but I'm going to do it anyway.
}